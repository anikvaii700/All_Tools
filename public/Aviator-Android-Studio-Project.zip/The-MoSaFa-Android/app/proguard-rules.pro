# ProGuard configuration for WebView
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}